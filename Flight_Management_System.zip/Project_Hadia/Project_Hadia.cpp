#include <iostream>
#include <conio.h>
#include <fstream>
#include <string>
using namespace std;

class Planes
{

public:
    
    string name;
    string airport;
    string type;
    string max_hrs;
    int seats;
    int id;

    Planes()
    {
        type = "International";
    }
    
    Planes(int id, string name, string airp, string max_hr, int seat)
    {
        this->name = name;
        airport = airp;
        this->id = id;
        max_hrs = max_hr;
        seats = seat;
    }

    void Display()
    {
        cout << endl <<endl << "**********   Planes and airports Information   **********" << endl;
        cout << endl << endl << "  Plane_Specs          Airport           Type           No_of_Seats available        " << endl;
        cout << endl << "    " << name << "       " << airport << "          " << type << "          " << seats << endl << endl ;
    }
};

class FlightSchedule
{

protected:
    string from;
    string to;
    string D_time;
    string A_time;
    int ID;
    int Current_seats;

public:

    FlightSchedule()
    {
    }

    void Disp()
    {
        cout << endl << endl << "Flights Schedule--------------------------------------" << endl << endl;
        //cout << "\n\n----------------------------------------Local And International Flights  Schedule--------------------------------------\n";
        cout << endl << "             From           To           Departure-Time         Arrival-Time       No_of_seats_available    " << endl << endl;
    }
};

int a1 = 12345;
int a2 = 678910;
int a3 = 1112131415;

class LocalFlights : public FlightSchedule
{

public:

    LocalFlights()
    {
    }

    LocalFlights(int id, string frm, string towards, string departure, string arrival, int seats)
    {
        from = frm;
        to = towards;
        D_time = departure;
        A_time = arrival;
        Current_seats = seats;
        ID = id;
    }

    void Display()
    {
        cout << endl << endl << "**********   Local Flights  Schedule   **********" << endl ;
        cout << "           " << from << "           " << to << "           " << D_time << "           " << A_time << "           " << Current_seats << endl << endl;
    }
};

class International_Flights : public FlightSchedule
{

public:

    International_Flights()
    {
    }

    International_Flights(int Id, string frm, string towards, string departure, string arrival, int seats)
    {
        from = frm;
        to = towards;
        D_time = departure;
        A_time = arrival;
        Current_seats = seats;
        ID = Id;
    }

    void Display()
    {
        cout << endl << endl << "**********   International Flights Schedule   **********"<<endl;
        cout << endl << "        " << from << "        " << to << "            " << D_time << "             " << A_time << "              " << Current_seats << endl << endl;
    }
};

class Indirect_flights : public FlightSchedule
{

protected:
    string sty;
    int ID;

public:
    Indirect_flights(int id, string frm, string towards, string stay, string departure, string arrival, int seats)
    {
        from = frm;
        to = towards;
        D_time = departure;
        A_time = arrival;
        Current_seats = seats;
        sty = stay;
        ID = id;
    }

    void Display()
    {
        cout << endl << endl << "**********   Indirect Flights   **********" << endl << endl;
        cout << endl << "             From           To            Stay          Departure-Time         Arrival-Time       No_of_seats_available    \n " << endl;
        cout << "           " << from << "           " << to << "           " << D_time << "           " << A_time << "           " << Current_seats << endl << endl;
    }
};

class Login
{
protected:
    string name;
    string st;
    char password[8];

public:
    virtual void setData()
    {
        cout << endl << "**********   Enter your name   **********" << endl;
        cin >> name;
    }
};

class PassengerPanel : public Login

{

private:
    int cnic[13];

public:

    void setData()
    {
        char a;
        int check;
        cout << endl << endl << "**********   Enter Your Name   **********" << endl;
        cin >> name;

        ofstream out("passengers.txt", ios::app);
        out << name;

        cout << endl << "**********   Enter a password :: It must be 8 caharacters long/use of special/ upper case / lower case characters is must " << endl << endl;

        for (int i = 0; i < 8;)
        {
            a = getc(stdin);
            password[i] = a;
            i++;
            cout << "*";
        }

        /*cout << endl << " Re-enter your password " << endl;
        for (int i = 0; i < 8;)
        {
            a = getc(stdin);
            password[i] = a;
            i++;
            cout << "*";
        }*/

        check = validation();
        if (check == 1)
        {
            cout << endl << " Password is validated " << endl;
            for (int i = 0; i < 8; i++)
            {
                out << " " << password[i];
            }
        }

        else
        {
            while (validation() != 1)
            {
                cout << endl << "**********   Enter a password :: It must be 8 caharacters long/use of special/ upper case / lower case characters is must\n\n ";
                for (int i = 0; i < 8;)
                {
                    a = getc(stdin);
                    password[i] = a;
                    i++;
                    cout << "*";
                }
            }
        }

        cout << "**********   Enter a valid CNIC number   **********" << endl;
        for (int i = 0; i < 13; i++)
        {
            cin >> cnic[i];

            out << "  " << cnic[i];
            out.close();
        }
        cout << endl << " CNIC ENTERED SUCESSFULLY " << endl;
        cout << endl << " You are registered SUCESSFULLY " << endl;
    }

    int validation()
    {
        int up = 0;
        int low = 0;
        int num = 0;
        int special = 0;

        for (int i = 0; i < 8; i++)
        {
            if (password[i] >= 'A' && password[i] <= 'Z')
            {
                up++;
            }

            if (password[i] >= 'a' && password[i] <= 'z')
            {
                low++;
            }

            if (password[i] >= '0' && password[i] <= '9')
            {
                num++;
            }
            else
            {
                special++;
            }
        }
        if (up > 0 && low > 0 && num > 0 && special > 0)
        {
            cout << " Password Entered Sucessfully " << endl;

            ofstream o1("passengers.txt", ios::app);
            for (int i = 0; i < 8; i++)
            {
                o1 << " " << password[i];
                o1.close();
            }

            return 1;
        }
        else
        {
            cout << endl << " Invalid Password " << endl;
            return -1;
        }
    }
};

class AdminPanel : public Login
{

public:
    void setData()
    {
        char a;
        int check;
        cout << endl << endl << "**********   Enter Your Name   **********" << endl;
        
        cin>> name;

        ofstream out("admin.txt", ios::app);
        out << name;

        cout << endl << "**********   Enter a password :: It must be 8 caharacters long/use of special/ upper case / lower case characters is must " << endl << endl;
        for (int i = 0; i < 8;)
        {
            a = cin.get();
            //a = getc(stdin);
            password[i] = a;
            i++;
            cout << "*";
        }
        check = validation();
        if (check == 1)
        {
            cout << endl << " Password is validated " << endl;
            for (int i = 0; i < 8; i++)
            {
                out << " " << password[i];
                out.close();
            }
        }
        else
        {
            while (validation() != 1)
            {
                cout << endl << "**********   Enter a password :: It must be 8 caharacters long/use of special/ upper case / lower case characters is must\n\n ";
                for (int i = 0; i < 8;)
                {
                    a = getc(stdin);
                    password[i] = a;
                    i++;
                    cout << "*";
                }
            }
        }
    }

    int validation()
    {
        int up = 0;
        int low = 0;
        int num = 0;
        int special = 0;

        for (int i = 0; i < 8; i++)
        {
            
            if (password[i] >= 'A' && password[i] <= 'Z')
            {
                up++;
            }

            if (password[i] >= 'a' && password[i] <= 'z')
            {
                low++;
            }

            if (password[i] >= '0' && password[i] <= '9')
            {
                num++;
            }
            
            else
            {
                special++;
            }
        }

        if (up > 0 && low > 0 && num > 0 && special > 0)
        {
            cout << " Password Entered Sucessfully " << endl;

            ofstream o1("admin.txt", ios::app);
            
            for (int i = 0; i < 8; i++)
            {
                o1 << " " << password[i];
                o1.close();
            }

            return 1;
        }
        
        else
        {
            cout << endl << " Invalid Password " << endl;
            return -1;
        }
    }

    void AddNewRoute() //this function will update flight schedule
    {
        static string* to = new string[10];
        static string* from = new string[10];
        string a, b;
        int x;
        int n = 0;

        LocalFlights* loc[10];
        cout << endl << endl <<"***********   Updating flight schedule For local flights   **********" << endl;
        cout << endl << " How many flights you wanna add " << endl;
        cin >> n;

        for (int i = 0, j = 0; i < n; i++)
        {
            cout << endl << endl << "**********   Enter the city to start the flight from   ***********"<< endl << endl;
            cin >> to[i];
            cout << endl << endl << "**********   Enter the city of Destination   **********" << endl << endl;
            cin >> from[i];
            cout << endl << endl << "**********   Schedule Departure time   **********" << endl << endl;
            cin >> a;
            cout << endl << endl << "**********   Schedule arrival time   **********" << endl << endl;
            cin >> b;
            cout << endl << endl << "**********   Enter the number of seats   **********" << endl << endl;
            cin >> x;
            loc[i] = new LocalFlights(i, to[i], from[i], a, b, x);
        }
        // cout << "\n             From           To           Departure-Time         Arrival-Time       No_of_seats_available    \n " << endl;
        for (int i = 0; i < n; i++)
        {
            loc[i]->Display();
        }
    }

    void UpdateSchedule(int num, LocalFlights* k[])
    {
        static string* to = new string[10];
        static string* from = new string[10];
        string a, b;
        int x;
        int n = 0;

        LocalFlights* l[10];
        cout << endl << endl << "**********   Updating flight schedule For local flights   **********" << endl;
        cout << endl << " How many flights you wanna add " << endl;
        cin >> n;

        for (int i = 0, j = 0; i < n; i++)
        {
            cout << endl << endl << "**********   Enter the city to start the flight from   **********" << endl << endl;
            cin >> to[i];
            cout << endl << endl << "**********   Enter the city of Destination **********" << endl << endl;
            cin >> from[i];
            cout << endl << endl << "**********   Schedule Departure time   **********" << endl << endl;
            cin >> a;
            cout << endl << endl << "**********   Schedule arrival time   **********" << endl << endl;
            cin >> b;
            cout << endl << endl <<"**********   Enter the number of seats   **********" << endl << endl;
            cin >> x;
            l[i] = new LocalFlights(i, to[i], from[i], a, b, x);
        }
        // cout << "\n             From           To           Departure-Time         Arrival-Time       No_of_seats_available    \n " << endl;
        for (int i = 0; i < num; i++) //displaying the local flights
        {
            k[i]->Display();
        }
        for (int i = 0; i < n; i++)
        {
            l[i]->Display();
        }
    }
};

class ShortestFlight
{
private:
    string from;
    string to;
    int hours;
    double cost;

public:
    ShortestFlight()
    {
        from = "Pakistan";
        to = "USA";
        hours = 13;
        cost = 150, 000;
    }

    void Display()
    {
        cout << endl << endl << " From             To       No of hours     Total_Cost         Tentative_timings" << endl;
        cout << endl << "  " << from << "       " << to << "    " << hours << "    " << cost << "         8:30 am to 12::00 pm" << endl;
    }
};

class Regsitered_passengers
{
private:
    int password;
    string details;

public:
    void DisplayDetails1() //calling function to display the details of passengers
    {
        // ifstream infile;
        // infile.open("RegisteredUsers.txt");
        // while (!infile.eof())
        // {
        //     getline(infile, details);
        //     cout << details;
        // }
        // infile.close();

        cout << endl << endl << "**********   Details   **********" << endl;
        cout << endl << " Name:  Faria Eman " << endl << endl;
        cout << "FatherName: Ahmed Saleem " << endl;
        cout << "DateOFBIRTH: 23/2/1998 " << endl;
        cout << "Nationality: Pakistan " << endl;
        cout << "Religion: Islam " << endl;
        cout << "CNIC: 1-3454-322232-0 " << endl;
        cout << endl << endl << " Travel History " << endl << endl;
        cout << "23/2/1998   Pakistan     America " << endl;
        cout << "24/6/2001   Pakistan     Malysia " << endl;
        cout << "23/3/2001   Pakistan     bali" << endl;
        cout << "24/2/2008   Pakistan     Indonesia " << endl;
        cout << "Most Visted Country:     America " << endl;

    }

    void DisplayDetails2() //calling function to display the details of passengers
    {
        // ifstream infile;
        // infile.open("ru2.txt");
        // while (!infile.eof())
        // {
        //     getline(infile, details);
        //     cout << details;
        // }
        // infile.close();
        cout << endl << endl << "**********   Details   **********" << endl;
        cout << endl << " Name:  Ahmed Ejaz " << endl << endl;
        cout << "FatherName: Ahmed Saleem " << endl;
        cout << "DateOFBIRTH: 23/2/1998 " << endl;
        cout << "Nationality: Pakistan " << endl;
        cout << "Religion: Islam " << endl;
        cout << "CNIC: 1-3454-322232-0 " << endl;
        cout << endl << endl << " Travel History " << endl  << endl;
        cout << "23/2/1998   Pakistan     America " << endl;
        cout << "24/6/2001   Pakistan     Malysia " << endl;
        cout << "23/3/2001   Pakistan     bali" << endl;
        cout << "24/2/2008   Pakistan     Indonesia " << endl;
        cout << "Most Visted Country:     America " << endl;
    }

    void DisplayDetails3() //calling function to display the details of passengers
    {
        // ifstream infile;
        // infile.open("ru2.txt");
        // while (!infile.eof())
        // {
        //     getline(infile, details);
        //     cout << details;
        // }
        // infile.close();
        cout << endl << endl << "**********   Details   **********" << endl;
        cout << endl << " Name:  Hadia Raheel "<< endl << endl;
        cout << "FatherName: Raheel Ahmed " << endl;
        cout << "DateOFBIRTH: 01/5/1948 " << endl;
        cout << "Nationality: Pakistan " << endl;
        cout << "Religion: Islam " << endl;
        cout << "CNIC: 1-3454-322232-0 " << endl;
        cout << endl << endl << " Travel History " << endl << endl;
        cout << "23/2/1998   Pakistan     America " << endl;
        cout << "24/6/2001   Pakistan     Malysia " << endl;
        cout << "23/3/2004   Pakistan     America" << endl;
        cout << "24/2/2008   Pakistan     Indonesia " << endl;
        cout << "Most Visted Country:     America " << endl;
    }

};

class Booking
{

private:

    int choice;
    double cost1;
    double cost2;
    double cost3;
    double cost4;

public:
    void Local(int num, LocalFlights* q[])
    {
        for (int i = 0; i < num; i++)
        {
            q[i]->Display();
        }
        cout << endl << endl << "Select the the city and the destination you want to go for " << endl << endl;

        cin >> choice;
        cost1 = 2 * 10000;
        cost1 += (cost1 * 10) / 100;
        cost1 -= (cost1 * 20) / 100;
        cout << endl << endl << " The cost of the ticket is " << cost1 << endl;
    }
    void international(int num, International_Flights* f[])
    {
        for (int i = 0; i < num; i++)
        {
            f[i]->Display();
        }
        cout << endl << endl << "Select the the country and the destination you want to go for " << endl << endl;

        cin >> choice;
        cost2 = 13 * 20000;
        cost2 += (cost2 * 10) / 100;
        cost2 -= (cost2 * 20) / 100;
        cout << endl << endl << " The cost of the ticket is " << cost2 << endl;
    }
    void special(int num, ShortestFlight q)
    {
        q.Display();

        cout << endl << endl << "This is a special flight to USA " << endl << endl;

        //cin >> choice;
        cost3 = 13 * 20000;
        //cost3 += (cost3 * 10) / 100;
        //cost3 -= (cost2 * 20) / 100;
        cout << endl << endl << " The cost of the ticket is " << cost3 << endl;
    }
    void Indirect(int num, Indirect_flights* q[])
    {
        for (int i = 0; i < num; i++)
        {
            q[i]->Display();
        }
        cost4 = 2 * 10000;
        cost4 += (cost4 * 10) / 100;
        cost4 -= (cost4 * 20) / 100;
        cout << endl << endl << " The cost of the ticket is " << cost4 << endl;
    }
    friend ostream& operator<<(ostream& out, const Booking& c);
};

ostream& operator<<(ostream& out, const Booking& c)
{
    out << c.cost1 << endl;
    out << c.cost2 << endl;
    out << c.cost3 << endl;
    out << c.cost4 << endl;

    return out;
}

int main()

{
    PassengerPanel p1;

    string* local_from = new string[10];
    local_from[0] = "Islamabad_North";
    local_from[1] = "Lahore_North";
    local_from[2] = "Quetta_North";
    local_from[3] = "Peshawar_North";
    local_from[4] = "Karachi_North";
    local_from[5] = "Islamabad_South";
    local_from[6] = "Lahore_South";
    local_from[7] = "Quetta_South";
    local_from[8] = "Peshawar_South";
    local_from[9] = "Karachi_South";

    string* int_flights = new string[5];

    int_flights[0] = "Duabi";
    int_flights[1] = "Canada";
    int_flights[2] = "USA";
    int_flights[3] = "Saudia Arabia";
    int_flights[4] = "China";

    string* local_to = new string[10];
    
    local_from[9] = "Islamabad_";
    local_from[8] = "Lahore";
    local_from[7] = "Quetta";
    local_from[6] = "Peshawar";
    local_from[5] = "Karachi";
    local_from[4] = "Sialkot";
    local_from[3] = "Multan";
    local_from[2] = "Quetta_South";
    local_from[1] = "Peshawar_South";
    local_from[0] = "Karachi_South";

    string* int_flights_from = new string[5];

    int_flights_from[4] = "Duabi";
    int_flights_from[3] = "Canada";
    int_flights_from[2] = "Korea";
    int_flights_from[1] = "Saudia Arabia";
    int_flights_from[0] = "China";

    string* name = new string[10];

    name[0] = "PK-101";
    name[1] = "PK-102";
    name[2] = "PF-101";
    name[3] = "PF-102";
    name[4] = "PA-101";
    name[5] = "PA-102";
    name[6] = "9P-101";
    name[7] = "9P-102";
    name[8] = "ER-101";
    name[9] = "ER-102";

    string* air = new string[10];

    air[0] = "Islamabad North International";
    air[1] = "Allama Iqbal North International";
    air[2] = "Quetta North International ";
    air[3] = "Bacha Khan North International";
    air[4] = "Jinnah North International";
    air[5] = "Allama Iqbal South International";
    air[6] = "Islamabad South International";
    air[7] = "Quetta South International";
    air[8] = "Bacha Khan South International";
    air[9] = "Jinnah South International";

    Booking b1;

    Planes* p[10];

    for (int i = 0, j = 0; i < 10; i++, j++)
    {
        p[i] = new Planes(i, name[i], air[i], "10 hours", i + 10);
    } //loop to be added to display it

    LocalFlights* loc[10];

    for (int i = 0, j = 0; i < 10; i++, j++)
    {
        loc[i] = new LocalFlights(i, local_from[i], local_to[j], " 7: 30 am ", " 9 : 30 am ", 10);
    }

    International_Flights* intel[5];

    for (int i = 0, j = 0; i < 5; i++, j++)
    {
        intel[i] = new International_Flights(i, int_flights[i], int_flights_from[j], " 7 : 30 pm ", " 10 : 30 am", 50);
    }

    Indirect_flights* In[5];

    for (int i = 0, j = 0; i < 5; i++, j++)
    {
        In[i] = new Indirect_flights(i, local_from[i], local_to[j], local_to[j + 1], "3:30 pm", "4:30 pm", 50);
    } //a function is to be added to display indirect flights

    int choice1 = 0;
    int choice2 = 0;

    int pa;
    Regsitered_passengers r1;
    ShortestFlight q;

START:

    cout << endl <<endl << "*************************   Welcome TO NUCES Airline Flight System   *************************"<< endl << endl << endl;
    cout << endl << "                            Press 1 if you want to login to Admin Panel" << endl;
    cout << endl << "                            Press 2 if you want to login to User panel     " << endl;
    cout << endl << "                            Press 3 to exit the program     " << endl <<endl;
    
    cin >> choice1;

    if (choice1 == 1)
    {

        int role;
        AdminPanel a1;
        a1.setData();
        
        cout << endl << endl << " Press 1 to update the schedule. " << endl;
        cout << endl << endl << " Press 2 to add new route." << endl;
        cout << endl << endl << " Press 3 to see the Airplane details. " << endl <<endl;

        cin >> role;

        if (role == 1)
        {
            a1.UpdateSchedule(10, loc);

            goto START;
        }

        else if (role == 2)
        {
            a1.AddNewRoute();

            goto START;

        }

        else if (role == 3)
        {
            
            for (int i = 0; i < 10; i++) //displaying planes
            {
                p[i]->Display();
            }

            goto START;

        }
    }

    else if (choice1 == 2)
    {

        cout << endl << endl << " Welcome !!!!   Press 1 if you are a registered user." << endl;
        cout << endl << endl << " Press 2 if you want to get yourself registered " <<endl;
        cin >> choice2;

        if (choice2 == 1)
        {

            int choice3;
            cout << endl << " Enter your password to see extended Details " << endl;
            cin >> pa;
            
            if (pa == a1)
            {

                r1.DisplayDetails1();

                cout << endl << " Press 1 to see the details of all the flights " << endl;
                cout << endl << " Press 2 to see the details of the LOCAL Flights the flights " << endl;
                cout << endl << " Press 3 to see the details of the INTERNATIONAL Flights the flights " << endl;
                cout << endl << " Press 4 to see the details of the INDIRECT Flights the flights " << endl;
                cout << endl << " Press 5 to see the details of our AIRPLANES operations " << endl;
                cout << endl << " Press 6 to BOOK a flight " << endl;
                cout << endl << " Press 7 to update your username and password " << endl;
                cout << endl << " Press 0 to exit " << endl;

                cin >> choice3;
                
                if (choice3 == 1)
                {
                    
                    FlightSchedule f1;
                    f1.Disp();

                    for (int i = 0; i < 10; i++) //displaying the local flights
                    {
                        loc[i]->Display();
                    }
                
                    for (int i = 0; i < 5; i++) //displaying international flights
                    {
                        intel[i]->Display();
                    }
                    
                    for (int i = 0; i < 5; i++) //displaying indirect flights
                    {
                        In[i]->Display();
                    }
                    
                    cout << endl << " The shortest flight to USA is available " << endl;
                    q.Display();

                    goto START;

                }
                
                else if (choice3 == 2)
                {
                
                    for (int i = 0; i < 10; i++) //displaying the local flights
                    {
                        loc[i]->Display();
                    }
                    
                    goto START;

                }
                
                else if (choice3 == 3)
                {
                
                    for (int i = 0; i < 5; i++) //displaying international flights
                    {
                        intel[i]->Display();
                    }
                    
                    cout << endl << " The shortest flight to USA is available " << endl;
                    q.Display();

                    goto START;

                }
                
                else if (choice3 == 4)
                {
                
                    for (int i = 0; i < 5; i++) //displaying indirect flights
                    {
                        In[i]->Display();
                    }

                    goto START;

                }
                
                else if (choice3 == 5)
                {
                
                    for (int i = 0; i < 10; i++) //displaying planes
                    {
                        p[i]->Display();
                    }

                    goto START;

                }
                
                else if (choice3 == 6)
                {
                    int choice4 = 0;

                    cout << " Press 1 to book a local flight " << endl << endl;                        
                    cout << " Press 2 to book a International flight " << endl << endl;                       
                    cout << " Press 3 to book a Indirect flight " << endl << endl;                       
                    cout << " Press 4 to book a the shortest flight " << endl << endl;

                    cin >> choice4;

                    if (choice4 == 1)
                    {
                        b1.Local(10, loc);
                        cout << endl << endl << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are " <<endl <<endl;
                        p[1]->Display();

                       // goto START;

                    }
                    
                    else if (choice4 == 2)
                    {
                        b1.international(5, intel);
                        cout << endl << endl << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << " Your flight Details are " << endl << endl;
                        p[2]->Display();

                    }
                    
                    else if (choice4 == 3)
                    {
                        b1.Indirect(5, In);
                        cout << endl << endl << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are " << endl << endl;
                        p[3]->Display();
                    }
                    
                    else if (choice4 == 4)
                    {
                        b1.special(1, q);
                    }
               
                }
                
                else if (choice3 == 7)
                {
                    p1.setData();

                    //goto START;

                }
                
                else if (choice3 == 0)
                {
                    goto START;
                }

            }
            
            else if (pa == a2)
            {
                
                int choice3 = 0;

                r1.DisplayDetails2();
                
                cout << endl << " Press 1 to see the details of all the flights " << endl;
                cout << endl << " Press 2 to see the details of the LOCAL Flights the flights " << endl;
                cout << endl << " Press 3 to see the details of the INTERNATIONAL Flights the flights " << endl;
                cout << endl << " Press 4 to see the details of the INDIRECT Flights the flights " << endl;
                cout << endl << " Press 5 to see the details of our AIRPLANES operations " << endl;
                cout << endl << " Press 6 to BOOK a flight. " << endl;
                cout << endl << " Press 7 to update your username and password " << endl;
                
                cin >> choice3;
                
                if (choice3 == 1)
                {

                    FlightSchedule f1;
                    f1.Disp();

                    for (int i = 0; i < 10; i++) //displaying the local flights
                    {
                        loc[i]->Display();
                    }
                    
                    for (int i = 0; i < 5; i++) //displaying international flights
                    {
                        intel[i]->Display();
                    }
                    
                    for (int i = 0; i < 5; i++) //displaying indirect flights
                    {
                        In[i]->Display();
                    }
                    
                    cout << "\n The shortest flight to USA is available " << endl;
                    q.Display();

                    goto START;

                }
                
                else if (choice3 == 2)
                {
                    
                    for (int i = 0; i < 10; i++) //displaying the local flights
                    {
                        loc[i]->Display();
                    }

                    goto START;

                }
                
                else if (choice3 == 3)
                {
                    
                    for (int i = 0; i < 5; i++) //displaying international flights
                    {
                        intel[i]->Display();
                    }

                    cout << endl << " The shortest flight to USA is available " << endl;
                    q.Display();

                    goto START;

                }

                else if (choice3 == 4)
                {
                    
                    for (int i = 0; i < 5; i++) //displaying indirect flights
                    {
                        In[i]->Display();
                    }

                    goto START;

                }

                else if (choice3 == 5)
                {
                    
                    for (int i = 0; i < 10; i++) //displaying planes
                    {
                        p[i]->Display();
                    }

                    goto START;

                }

                else if (choice3 == 6)
                {
                    int choice4 = 0;

                    cout << " Press 1 to book a local flight " << endl << endl;                       
                    cout << " Press 2 to book a International flight " << endl << endl;                       
                    cout << " Press 3 to book a Indirect flight " << endl << endl;
                    cout << " Press 4 to book a the shortest flight " << endl << endl;
                    
                    cin >> choice4;

                    if (choice4 == 1)
                    {
                        b1.Local(10, loc);
                        cout << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are " << endl << endl;
                        p[4]->Display();

                        goto START;

                    }
                    
                    else if (choice4 == 2)
                    {
                        b1.international(5, intel);
                        cout << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are " << endl << endl;
                        p[5]->Display();

                        goto START;

                    }
                    
                    else if (choice4 == 3)
                    {
                        b1.Indirect(5, In);
                        cout << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are " << endl << endl;
                        p[3]->Display();

                        goto START;

                    }

                    else if (choice4 == 4)
                    {
                        b1.special(1, q);
                    }

                }
                
                else if (choice3 == 7)
                {
                    p1.setData();

                }
                
                else if (choice3 == 0)
                {
                    goto START;
                }
            }
            
            else if (pa == a3)
            {

                int choice3 = 0;
                r1.DisplayDetails3();

                cout << endl << " Press 1 to see the details of all the flights " << endl;
                cout << endl << " Press 2 to see the details of the LOCAL Flights the flights " << endl;
                cout << endl << " Press 3 to see the details of the INTERNATIONAL Flights the flights " << endl;
                cout << endl << " Press 4 to see the details of the INDIRECT Flights the flights " << endl;
                cout << endl << " Press 5 to see the details of our AIRPLANES operations " << endl;
                cout << endl << " Press 6 to BOOK a flight " << endl;
                cout << endl << " Press 7 to update your username and password " << endl;

                cin >> choice3;

                if (choice3 == 1)
                {
                
                    FlightSchedule f1;
                    f1.Disp();

                    for (int i = 0; i < 10; i++) //displaying the local flights
                    {
                        loc[i]->Display();
                    }
                    
                    for (int i = 0; i < 5; i++) //displaying international flights
                    {
                        intel[i]->Display();
                    }
                    
                    for (int i = 0; i < 5; i++) //displaying indirect flights
                    {
                        In[i]->Display();
                    }

                    goto START;

                }
                
                else if (choice3 == 2)
                {
                    
                    for (int i = 0; i < 10; i++) //displaying the local flights
                    {
                        loc[i]->Display();
                    }

                    goto START;

                }

                else if (choice3 == 3)
                {
                    
                    for (int i = 0; i < 5; i++) //displaying international flights
                    {
                        intel[i]->Display();
                    }

                    cout << endl << " The shortest flight to USA is available " << endl;
                    q.Display();
                
                    goto START;

                }

                else if (choice3 == 4)
                {
                    
                    for (int i = 0; i < 5; i++) //displaying indirect flights
                    {
                        In[i]->Display();
                    }

                    goto START;

                }

                else if (choice3 == 5)
                {
                    
                    for (int i = 0; i < 10; i++) //displaying planes
                    {
                        p[i]->Display();
                    }

                    goto START;

                }

                else if (choice3 == 6)
                {
                    int choice4 = 0;

                    cout << " Press 1 to book a local flight " << endl << endl;                       
                    cout << " Press 2 to book a International flight " << endl << endl;
                    cout << " Press 3 to book a Indirect flight " << endl << endl;
                    cout << " Press 4 to book a the shortest flight " << endl << endl;

                    cin >> choice4;

                    if (choice4 == 1)
                    {
                        b1.Local(10, loc);
                        cout << " Your seat has been reserved succssessfully " << endl;
                        cout << "\nYour flight Details are \n\n";
                        p[6]->Display();

                    }

                    else if (choice4 == 2)
                    {
                        b1.international(5, intel);
                        cout << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are " <<endl << endl;
                        p[7]->Display();

                    }

                    else if (choice4 == 3)
                    {
                        b1.Indirect(5, In);
                        cout << " Your seat has been reserved succssessfully " << endl;
                        cout << endl << "Your flight Details are" << endl << endl;
                        p[8]->Display();

                    }

                    else if (choice4 == 4)
                    {
                        b1.special(1, q);
                    }

                }

                else if (choice3 == 7)
                {
                    p1.setData();

                    goto START;
                }

                else if (choice3 == 0)
                {
                    goto START;
                }
            }

            else
            {
                cout << "INVALID password " << endl;

            }
        }

        else if (choice2 == 2)
        {
            int choice3 = 0;

            cout << endl << endl << " Press 6 to get yourself registered " <<endl ;
            cout << endl << " Press 1 to see the details of all the flights " << endl;
            cout << endl << " Press 2 to see the details of the LOCAL Flights the flights " << endl;
            cout << endl << " Press 3 to see the details of the INTERNATIONAL Flights the flights " << endl;
            cout << endl << " Press 4 to see the details of the INDIRECT Flights the flights " << endl;
            cout << endl << " Press 5 to see the details of our AIRPLANES operations " << endl;
            cout << endl << " Press 7 to exit to the main menu " << endl;
            
            cin >> choice3;
            
            if (choice3 == 6)
            {
                p1.setData();

                //goto START;

            }

            else if (choice3 == 1)
            {
                
                FlightSchedule f1;
                f1.Disp();

                for (int i = 0; i < 10; i++) //displaying the local flights
                {
                    loc[i]->Display();
                }

                for (int i = 0; i < 5; i++) //displaying international flights
                {
                    intel[i]->Display();
                }
                
                for (int i = 0; i < 5; i++) //displaying indirect flights
                {
                    In[i]->Display();
                }

                goto START;

            }

            else if (choice3 == 2)
            {
                
                for (int i = 0; i < 10; i++) //displaying the local flights
                {
                    loc[i]->Display();
                }

                goto START;
            
            }

            else if (choice3 == 3)
            {
                
                for (int i = 0; i < 5; i++) //displaying international flights
                {
                    intel[i]->Display();
                }

                goto START;

            }
            
            else if (choice3 == 4)
            {
                
                for (int i = 0; i < 5; i++) //displaying indirect flights
                {
                    In[i]->Display();
                }

                goto START;

            }
            
            else if (choice3 == 5)
            {
                
                for (int i = 0; i < 10; i++) //displaying planes
                {
                    p[i]->Display();
                }

                goto START;

            }
            
            else if (choice3 == 7)
            {
                goto START;
            }

        }
    }


    else if (choice1 == 0)
    {
        cout << endl << " Thankyou!! for choosing us " << endl;
    }

    return 0;
}